package br.com.bb.progWeb_mvcSistemaBancarioGradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgWebMvcSistemaBancarioGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgWebMvcSistemaBancarioGradleApplication.class, args);
	}
}
